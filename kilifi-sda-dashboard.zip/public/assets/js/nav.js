// const createNav = () => {
//     let nav = document.querySelector('.navbar');
//     nav.innerHTML = `
//        <nav id="navbar" class="navbar">
//         <ul>
//           <li><a class="active " href="index">Home</a></li>
//           <li><a href="about">About</a></li>
//           <li><a href="communication">Communication</a></li>
//           <li><a href="gallery">Gallery</a></li>
//           <li><a href="clerk">Clerk's Desk</a></li>
//           <li><a href="blog">Blog</a></li>
//           <li class="dropdown"><a href="#"><span>Spiritual Materials</span> <i class="bi bi-chevron-down"></i></a>
//             <ul>
//               <li><a href="video-page">Videos</a></li>
//               <li class="dropdown"><a href="#"><span>Online Platforms</span> <i class="bi bi-chevron-right"></i></a>
//                 <ul>
//                   <li><a href="https://www.amazingfacts.org/" target="_blank">Amazing Facts</a></li>
//                   <li><a href="https://hck.co.ke/" target="_blank">Hope Channel</a></li>
//                   <li><a href="https://3abn.org/" target="_blank">3ABN</a></li>
//                   <li><a href="https://www.adventist.org/" target="_blank">Adventists.org</a></li>
//                 </ul>
//               </li>
//               <li><a href="literature">Literature/Articles</a></li>
//             </ul>
//           </li>
//           <li><a href="contact">Contact Us</a></li>
//         </ul>
//         <i class="bi bi-list mobile-nav-toggle"></i>
//       </nav>`
// }

// createNav();


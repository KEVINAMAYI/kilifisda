 <!-- Bootstrap core JavaScript-->
 <script src="corporate-dashboard/vendor/jquery/jquery.min.js"></script>
 <script src="corporate-dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

 <!-- Core plugin JavaScript-->
 <script src="corporate-dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>

 <script src="corporate-dashboard/vendor/datatables/jquery.dataTables.min.js"></script>


 <!-- Custom scripts for all pages-->
 <script src="corporate-dashboard/js/sb-admin-2.min.js"></script>

 <!-- Page level plugins -->
 <script src="corporate-dashboard/vendor/chart.js/Chart.min.js"></script>

 <script src="corporate-dashboard/vendor/datatables/dataTables.bootstrap4.min.js"></script>


 <!-- Page level custom scripts -->
 <script src="corporate-dashboard/js/demo/chart-area-demo.js"></script>
 <script src="corporate-dashboard/js/demo/chart-pie-demo.js"></script>

 <script src="corporate-dashboard/js/demo/datatables-demo.js"></script><?php /**PATH C:\laragon\www\kilifi-sda-dashboard\resources\views////corporate-dashboard/layouts/javascript.blade.php ENDPATH**/ ?>
// Call the dataTables jQuery plugin
$(document).ready(function() {

  //load datatables for each of this tables
  $('#reportTable').DataTable();
  $('#walletAccessControlTable').DataTable();
  $('#accountManagementTable').DataTable();
  $('#branchesTable').DataTable();
  $('#employeesTable').DataTable();
  $('#dashboardEmployeeTable').DataTable();


});

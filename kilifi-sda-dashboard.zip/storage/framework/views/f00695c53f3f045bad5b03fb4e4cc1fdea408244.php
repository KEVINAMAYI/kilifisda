
<?php /**PATH C:\laragon\www\kilifi-sda-dashboard\resources\views/auth/register.blade.php ENDPATH**/ ?>